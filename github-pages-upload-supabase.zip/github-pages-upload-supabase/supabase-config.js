// Fill in your Supabase project credentials.
// If left as placeholders, the app automatically falls back to local browser storage.
window.SUPABASE_CONFIG = {
  url: 'YOUR-PROJECT-URL',
  anonKey: 'YOUR-ANON-KEY'
};
